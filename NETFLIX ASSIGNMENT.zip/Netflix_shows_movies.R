library(ggplot2)
library(readr)
df <- read_csv("C:/Users/user/data/Netflix_shows_movies.csv")
ggplot(df, aes(x = rating)) +
  geom_bar(fill = "blue") +
  theme_minimal() +
  labs(title = "Ratings Distribution")
